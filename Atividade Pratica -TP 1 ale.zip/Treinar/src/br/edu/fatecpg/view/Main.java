package br.edu.fatecpg.view;
import br.edu.fatecpg.model.Pedido;

import java.util.ArrayList;

import br.edu.fatecpg.model.ItemPedido;


public class Main {
    public static void main(String[] args) {
        
        ItemPedido itemPedido1 = new ItemPedido("Prato1", 2, 29.99);
        ItemPedido itemPedido2 = new ItemPedido("Prato2", 5, 20);

       
        Pedido pedido = new Pedido(1, new ArrayList<>(), 5.00);
        
      
        pedido.adicionarItem(itemPedido1);
        pedido.adicionarItem(itemPedido2);

      
        System.out.println("Total do Pedido: " + pedido.calcularTotalPedido());

       
        System.out.println("Exibir Lista-> " + pedido.getLista());

       
        pedido.reservarMesa(2);
    }
}

