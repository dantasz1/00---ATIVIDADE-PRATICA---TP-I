package br.edu.fatecpg.model;

import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private int numeroDoPedido; 
    private List<ItemPedido> itens = new ArrayList<>();
    private double taxaDeEntrega;

    public Pedido(int numeroDoPedido, List<ItemPedido> itens, double taxaDeEntrega) {
        this.numeroDoPedido = numeroDoPedido;
        this.itens = new ArrayList<>(itens);
        this.taxaDeEntrega = taxaDeEntrega;
    }

    public double calcularTotalPedido() {
        double total = 0;
        for (ItemPedido itemPedido : itens) {
            total += itemPedido.getQuantidade() * itemPedido.getPrecoUnitario();
        }
        total += taxaDeEntrega;
        return total;
    }

    public void adicionarItem(ItemPedido item) {
        itens.add(item);
        System.out.println("Item adicionado com sucesso");
    }

    public void removerItem(ItemPedido item) {
        itens.remove(item);
        System.out.println("Item removido com sucesso");
    }

    public void reservarMesa(int numeroMesa) {
        System.out.println("Mesa " + numeroMesa + " reservada para o pedido " + numeroDoPedido);
    }

    public int getNumeroDoPedido() {
        return numeroDoPedido;
    }

    public void setNumeroDoPedido(int numeroDoPedido) {
        this.numeroDoPedido = numeroDoPedido;
    }

    public List<ItemPedido> getItens() {
        return itens;
    }

    public void setItens(List<ItemPedido> itens) {
        this.itens = itens;
    }

    public double getTaxaDeEntrega() {
        return taxaDeEntrega;
    }

    public void setTaxaDeEntrega(double taxaDeEntrega) {
        this.taxaDeEntrega = taxaDeEntrega;
    }

    public String getLista() {
        StringBuilder sb = new StringBuilder();
        for (ItemPedido itemPedido : itens) {
            sb.append(itemPedido.toString()).append("\n");
        }
        return sb.toString();
    }
}
