package br.edu.fatecpg.model;

public class Mesa {
    private int numeroMesa;
    private boolean reservada;

    public Mesa(int numeroMesa) {
        this.numeroMesa = numeroMesa;
        this.reservada = false; 
    }

    public int getNumeroMesa() {
        return numeroMesa;
    }

    public boolean isReservada() {
        return reservada;
    }

    public void setReservada(boolean reservada) {
        this.reservada = reservada;
    }
}
