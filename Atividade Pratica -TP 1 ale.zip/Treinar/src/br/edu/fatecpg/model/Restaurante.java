package br.edu.fatecpg.model;

import java.util.ArrayList;

public class Restaurante {

    private ArrayList<Pedido> pedidos = new ArrayList<>();

    
    public void adicionarPedido(Pedido pedido) {
        pedidos.add(pedido);
    }

    
    public void removerPedido(Pedido pedido) {
        pedidos.remove(pedido);
    }

   
    public void exibirPedidos() {
        if(pedidos.isEmpty()) {
            System.out.println("Nenhum pedido realizado.");
        } else {
            for(Pedido p : pedidos) {
                System.out.println(p);
            }
        }
    }

}
