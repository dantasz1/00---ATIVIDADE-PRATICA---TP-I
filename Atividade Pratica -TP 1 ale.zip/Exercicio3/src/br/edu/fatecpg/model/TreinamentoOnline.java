package br.edu.fatecpg.model;

import java.util.ArrayList;

public class TreinamentoOnline extends Treinamento {
    private String linkAcesso; 

    public TreinamentoOnline(int id, String nomeInstrutor, String linguagemEnsina, String nomePlano, double notaFinal, String linkAcesso) {
        super(id, nomeInstrutor, linguagemEnsina, new ArrayList<>(), nomePlano, notaFinal);
        this.linkAcesso = linkAcesso;
    }

    public String getLinkAcesso() {
        return linkAcesso;
    }

    public void setLinkAcesso(String linkAcesso) {
        this.linkAcesso = linkAcesso;
    }

    public void exibirLinkAcesso() {
        System.out.println("Link para o treinamento online: " + linkAcesso);
    }
}
