package br.edu.fatecpg.model;

import java.util.ArrayList;

public class Treinamento {
    private int id;
    private String nomeInstrutor;
    private String linguagemEnsina;
    private ArrayList<String> alunos; 
    private String nomePlano;
    private double notaFinal;

    public Treinamento(int id, String nomeInstrutor, String linguagemEnsina, ArrayList<String> alunos, String nomePlano, double notaFinal) {
        this.id = id;
        this.nomeInstrutor = nomeInstrutor;
        this.linguagemEnsina = linguagemEnsina;
        this.alunos = alunos;
        this.nomePlano = nomePlano;
        this.notaFinal = notaFinal;
    }

    public boolean verificarDisponibilidade() {
        return alunos.size() < 20; 
    }

    public void definirCargaHoraria(int horas) {
        System.out.println("Carga horária definida para " + horas + " horas.");
    }

    public boolean realizarUltimoTreinamento(String aluno) {
       
        if (notaFinal >= 7) {
            System.out.println("Aluno " + aluno + " pode realizar o último treinamento.");
            return true;
        } else {
            System.out.println("Aluno " + aluno + " não pode realizar o último treinamento.");
            return false;
        }
    }

    public double calcularMediaAlunos(ArrayList<Double> notas) {
        double soma = 0;
        for (double nota : notas) {
            soma += nota;
        }
        return soma / notas.size();
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomeInstrutor() {
        return nomeInstrutor;
    }

    public void setNomeInstrutor(String nomeInstrutor) {
        this.nomeInstrutor = nomeInstrutor;
    }

    public String getLinguagemEnsina() {
        return linguagemEnsina;
    }

    public void setLinguagemEnsina(String linguagemEnsina) {
        this.linguagemEnsina = linguagemEnsina;
    }

    public ArrayList<String> getAlunos() {
        return alunos;
    }

    public void setAlunos(ArrayList<String> alunos) {
        this.alunos = alunos;
    }

    public String getNomePlano() {
        return nomePlano;
    }

    public void setNomePlano(String nomePlano) {
        this.nomePlano = nomePlano;
    }

    public double getNotaFinal() {
        return notaFinal;
    }

    public void setNotaFinal(double notaFinal) {
        this.notaFinal = notaFinal;
    }
}
