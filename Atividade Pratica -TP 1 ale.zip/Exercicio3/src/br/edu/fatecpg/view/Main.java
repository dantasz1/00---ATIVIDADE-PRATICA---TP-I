package br.edu.fatecpg.view;


import br.edu.fatecpg.model.TreinamentoPresencial;
import br.edu.fatecpg.model.TreinamentoOnline;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
       
        ArrayList<String> alunos = new ArrayList<>();
        alunos.add("João");
        alunos.add("Maria");

        TreinamentoPresencial presencial = new TreinamentoPresencial(1, "Alessandro", "Java", "Plano Avançado", 8, "Sala 55");
        TreinamentoOnline online = new TreinamentoOnline(2, "André", "Python", "Plano Gratis", 7.0, "www.treinamentoOnlineGoogle.com");

       
        presencial.verificarDisponibilidade();
        presencial.definirCargaHoraria(50);
        online.realizarUltimoTreinamento("Maria");
        
       
        ArrayList<Double> notas = new ArrayList<>();
        notas.add(8.0);
        notas.add(7.5);
        System.out.println("Média das notas: " + presencial.calcularMediaAlunos(notas));

      
        presencial.exibirLocal();
        online.exibirLinkAcesso();
    }
}

