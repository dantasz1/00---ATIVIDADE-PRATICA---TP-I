package br.edu.fatecpg.view;

import br.edu.fatecpg.model.Voo;
import br.edu.fatecpg.model.Aeroporto;

public class Main {
    public static void main(String[] args) {
        Aeroporto aeroporto = new Aeroporto();

        Voo voo1 = new Voo("Voo1", "São Paulo", "Rio de Janeiro", 100);
        Voo voo2 = new Voo("Voo2", "Bahia", "Salvador", 150);

        aeroporto.adicionarVoo(voo1);
        aeroporto.adicionarVoo(voo2);

        aeroporto.exibirVoos();

       
        voo1.realizarReserva(50); 
        voo2.realizarReserva(200); 

       
        voo1.realizarPagamento("ida e volta", true);

      
        voo1.imprimirPassagem();
    }
}
