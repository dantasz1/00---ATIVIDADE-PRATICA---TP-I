package br.edu.fatecpg.model;

public class Voo {
    private String numeroVoo;
    private String origem;
    private String destino;
    private int quantidadeAssentos;
    private int assentosDisponiveis;

    public Voo(String numeroVoo, String origem, String destino, int quantidadeAssentos) {
        this.numeroVoo = numeroVoo;
        this.origem = origem;
        this.destino = destino;
        this.quantidadeAssentos = quantidadeAssentos;
        this.assentosDisponiveis = quantidadeAssentos;
    }

    public boolean realizarReserva(int quantidadeAssentos) {
        if (assentosDisponiveis >= quantidadeAssentos) {
            assentosDisponiveis -= quantidadeAssentos;
            System.out.println(quantidadeAssentos + " assento(s) reservado(s) com sucesso.");
            return true;
        } else {
            System.out.println("Não há assentos suficientes.");
            return false;
        }
    }

    public boolean verificarDisponibilidade(int quantidadeAssentos) {
        return assentosDisponiveis >= quantidadeAssentos;
    }

    public void realizarPagamento(String tipoViagem, boolean pontuacaoTuristico) {
        double taxaExtra = 0;
        if (pontuacaoTuristico) {
            taxaExtra = 50.0; 
        }
        if (tipoViagem.equals("ida e volta")) {
            taxaExtra += 100.0; 
        }
        System.out.println("Pagamento realizado com sucesso. Taxa adicional: " + taxaExtra);
    }

    public void imprimirPassagem() {
        System.out.println("Passagem: " + numeroVoo + " de " + origem + " para " + destino);
        System.out.println("Assentos disponíveis: " + assentosDisponiveis);
    }

    // Getters e Setters
    public String getNumeroVoo() {
        return numeroVoo;
    }

    public void setNumeroVoo(String numeroVoo) {
        this.numeroVoo = numeroVoo;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public int getQuantidadeAssentos() {
        return quantidadeAssentos;
    }

    public void setQuantidadeAssentos(int quantidadeAssentos) {
        this.quantidadeAssentos = quantidadeAssentos;
    }

    public int getAssentosDisponiveis() {
        return assentosDisponiveis;
    }

    public void setAssentosDisponiveis(int assentosDisponiveis) {
        this.assentosDisponiveis = assentosDisponiveis;
    }
}
